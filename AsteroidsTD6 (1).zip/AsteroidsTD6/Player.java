import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot und MouseInfo)

public class Player extends Actor
{
    float SpeedX; float AcclX;
    float SpeedY; float AcclY;
    int Rotation;
    float posX, posY; // echte Position als float

    float Beschleunigung = 0.3f; // f dafür dass Java weiß dass es ein Float ist.
    float Reibung = 0.98f;
    
    public Player() {
        posX = getX();
        posY = getY();
    }

    public void act() 
    {
        Bewegung();

        // Geschwindigkeit auf Position anwenden
        posX += SpeedX;
        posY += SpeedY;
        
        // Reibung für den Spieler
        SpeedX *= Reibung;
        SpeedY *= Reibung;
        
        setLocation(Math.round(posX), Math.round(posY)); //Math.round, da setLocation nur ganze Zahlen verkraftet :(
    }   

    public void Bewegung(){ //# Tastaturinputs in Bewegung
        // Vorwärts (W)
        if (Greenfoot.isKeyDown("w")) {
            double rad = Math.toRadians(getRotation()); // Umwandlung von Radiant zu Bogenmaß
            AcclX = (float)(Math.cos(rad) * Beschleunigung); //# Gibt den X-Anteil der Beschleunigung an
            AcclY = (float)(Math.sin(rad) * Beschleunigung); 

            SpeedX += AcclX;
            SpeedY += AcclY;
        }

        // Links (A)
        if (Greenfoot.isKeyDown("a")) {
            turn(-4);
        }

        // Rechts (D)
        if (Greenfoot.isKeyDown("d")) {
            turn(4);
        }
    }
}