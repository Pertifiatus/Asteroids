import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot und MouseInfo)

/**
 * Ergänzen Sie hier eine Beschreibung für die Klasse Asteroids.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Asteroids extends Actor
{
    float posX, posY; // echte Position als float
    float SpeedX;
    float SpeedY;
    float Rotation;
    public void act() {
        posX += SpeedX;
        posY += SpeedY;
        
        turn(Math.round(Rotation));
        setLocation(Math.round(posX), Math.round(posY)); //Math.round, da setLocation nur ganze Zahlen verkraftet :(
        OutofBoundaries();

    }    
    public void addedToWorld(World world) {
        posX = getX();  //Position Festlegen
        posY = getY();
        SpeedX=Greenfoot.getRandomNumber(10)-5;
        SpeedY=Greenfoot.getRandomNumber(10)-5;
        Rotation=Greenfoot.getRandomNumber(5)-2.5f;
    }

    public Asteroids() {
        GreenfootImage img = getImage();
        img.scale(img.getWidth() / 3, img.getHeight() / 3); // Bildskalierung

    }

    public void OutofBoundaries(){
        int worldWidth = getWorld().getWidth();
        int worldHeight = getWorld().getHeight();

        // X begrenzen
        if (posX < 0) {posX = worldWidth - 1;}
        if (posX > worldWidth - 1) {posX = 0;}

        // Y begrenzen
        if (posY < 0) {posY = worldHeight - 1;}
        if (posY > worldHeight - 1) {posY = 0;}
    }

}