import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot und MouseInfo)

/**
 * Ergänzen Sie hier eine Beschreibung für die Klasse MyWorld.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class MyWorld extends World
{

    public static int level = 1;

    public MyWorld()
    {    
        // Erstellt eine neue Welt mit 600x400 Zellen und einer Zell-Größe von 1x1 Pixeln.
        super(1750, 1000, 1); 
        GreenfootImage bg = getBackground();
        bg.setColor(Color.BLACK);
        bg.fill();
        setBackground(new GreenfootImage("Background.png"));
        Player spieler = new Player();
        addObject(spieler, getWidth()/2, getHeight()/2); // Startet in der Mitte der Welt
        
        for (int nr=1;nr<=2;nr++){
        
        int posX=Greenfoot.getRandomNumber(1920);
        int posY=Greenfoot.getRandomNumber(1080);
        Asteroids asteroid = new Asteroids();
        addObject(asteroid, posX, posY);    
        }

    }
}