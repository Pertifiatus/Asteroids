import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot und MouseInfo)

/**
 * Ergänzen Sie hier eine Beschreibung für die Klasse Asteroids.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Asteroids extends Actor
{
    float posX, posY; // echte Position als float
    float SpeedX;     // Geschwindigkeit in X-Richtung (Pixel pro Act)
    float SpeedY;     // Geschwindigkeit in Y-Richtung (Pixel pro Act)
    float Rotation;   // Eigenrotation in Grad pro Act
    int size; // Größe: 3=groß, 2=mittel, 1=klein

    public void act() {
        // Position um Geschwindigkeit weiterbewegen
        posX += SpeedX;
        posY += SpeedY;

        turn(Math.round(Rotation));
        setLocation(Math.round(posX), Math.round(posY)); //Math.round, da setLocation nur ganze Zahlen verkraftet :(
        OutofBoundaries();
        //checkAsteroidCollision();
    }

    // addedToWorld wird von Greenfoot aufgerufen sobald der Asteroid zur Welt hinzugefügt wird.
    // getX()/getY() funktionieren erst hier, nicht im Konstruktor (Actor ist noch nicht in der Welt).
    public void addedToWorld(World world) {
        posX = getX();  //Position Festlegen
        posY = getY();
        // Geschwindigkeit steigt pro Level um 20 %
        float speedFaktor = 1.0f + (MyWorld.level - 1) * 0.2f;
        SpeedX = (Greenfoot.getRandomNumber(10) - 5) * speedFaktor;
        SpeedY = (Greenfoot.getRandomNumber(10) - 5) * speedFaktor;
        // Zufällige Eigenrotation: -2.5 bis +2.5 Grad pro Act
        Rotation=Greenfoot.getRandomNumber(5)-2.5f;
    }

    public Asteroids() {
        this(3); // Standard: großer Asteroid
    }

    public Asteroids(int size) {
        this.size = size;
        GreenfootImage img = getImage();
        int divisor = getDivisorForSize(size);
        img.scale(img.getWidth() / divisor, img.getHeight() / divisor); // Bildskalierung
    }

    // Skalierungsfaktor je nach Größenstufe: 3=groß, 2=mittel, 1=klein
    private int getDivisorForSize(int size) {
        if (size == 3) return 4;
        if (size == 2) return 7;
        return 12;
    }

    // Kollisionsradius passend zur visuellen Größe – wird von Player und Projectile genutzt
    public int getHitRadius() {
        if (size == 3) return 60;
        if (size == 2) return 35;
        return 20;
    }

    // Wird vom Projektil aufgerufen: Asteroid entfernen und 2 kleinere spawnen
    public void split() {
        World world = getWorld();
        if (size > 1) {
            for (int i = 0; i < 2; i++) {
                Asteroids kleiner = new Asteroids(size - 1);
                // addObject ruft addedToWorld auf → setzt zufällige SpeedX/Y.
                // Danach überschreiben wir die Geschwindigkeit mit dem gewünschten Wert.
                world.addObject(kleiner, Math.round(posX), Math.round(posY));
                // Kleinere Asteroiden erben etwas Schwung und fliegen in verschiedene Richtungen
                // * 0.8f: etwas langsamer als Elternteil, ± 5 zufälliger Versatz für Aufspaltung
                kleiner.SpeedX = SpeedX * 0.8f + (Greenfoot.getRandomNumber(11) - 5);
                kleiner.SpeedY = SpeedY * 0.8f + (Greenfoot.getRandomNumber(11) - 5);
            }
        }
        // Kleinste Stufe (size 1) verschwindet einfach
        world.removeObject(this);
    }

    public void OutofBoundaries(){
        int worldWidth = getWorld().getWidth();
        int worldHeight = getWorld().getHeight();

        // X begrenzen
        if (posX < 0) {posX = worldWidth - 1;}
        if (posX > worldWidth - 1) {posX = 0;}

        // Y begrenzen
        if (posY < 0) {posY = worldHeight - 1;}
        if (posY > worldHeight - 1) {posY = 0;}
    }

    private void checkAsteroidCollision() {
        // Radius eines Asteroiden (da sie auf 1/3 skaliert sind, probier mal 30-40 Pixel) 
        float radius = 40.0f; 
        float collisionDist = radius * 2; 

        // Wir gehen alle anderen Asteroiden durch
        for (Asteroids other : getWorld().getObjects(Asteroids.class)) {
            if (other == this) continue; // Nicht mit sich selbst kollidieren!

            // Abstand berechnen (Satz des Pythagoras)
            float dx = this.posX - other.posX;
            float dy = this.posY - other.posY;
            float distance = (float)Math.sqrt(dx * dx + dy * dy);

            // distance > 0: Schutz vor Division durch Null falls zwei Asteroiden exakt gleiche Position haben
            if (distance < collisionDist && distance > 0) {
                // --- DER ABPRALL-EFFEKT ---
                float bouncePower = 0.05f; // Ein kleiner Schubs reicht oft schon

                // Wir ändern die Geschwindigkeit basierend auf der Richtung zum anderen Asteroiden
                this.SpeedX += (dx / distance) * bouncePower;
                this.SpeedY += (dy / distance) * bouncePower;
            }
        }
    }
}