import greenfoot.*;

public class Spritanzeige extends Actor
{
    private int maxSprit;
    private static final int BAR_BREITE = 200;
    private static final int BAR_HOEHE = 18;

    public Spritanzeige(int maxSprit) {
        this.maxSprit = maxSprit;
        update(maxSprit);
    }

    public void update(int sprit) {
        GreenfootImage img = new GreenfootImage(BAR_BREITE + 4, BAR_HOEHE + 22);

        // Label
        img.setColor(Color.WHITE);
        img.setFont(new Font("Arial", true, false, 13));
        img.drawString("SPRIT", 0, 13);

        // Leerer Tank (Hintergrund)
        img.setColor(Color.DARK_GRAY);
        img.fillRect(0, 16, BAR_BREITE + 4, BAR_HOEHE);

        // Füllstand
        int fuellBreite = (int)((double)sprit / maxSprit * BAR_BREITE);
        if (fuellBreite > 0) {
            if (sprit > maxSprit * 0.5) {
                img.setColor(new Color(50, 200, 50));   // grün
            } else if (sprit > maxSprit * 0.25) {
                img.setColor(new Color(230, 200, 0));   // gelb
            } else {
                img.setColor(new Color(220, 50, 50));   // rot
            }
            img.fillRect(0, 16, fuellBreite, BAR_HOEHE);
        }

        // Rahmen
        img.setColor(Color.WHITE);
        img.drawRect(0, 16, BAR_BREITE + 3, BAR_HOEHE - 1);

        setImage(img);
    }

    public void act() {}
}
