import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot und MouseInfo)

public class Player extends Actor
{
    //# Bilder Variablen
    private String[] bilder = {"Booster-5-1.png", "Booster-4.png", "Booster-3.png", "Booster-2.png", "Booster-1.png"}; //String für die Booster Abkühlung
    private String[] booster = {"Booster-5-1.png", "Booster-5-2.png", "Booster-5-3.png", "Booster-5-4.png", "Booster-5-5.png", "Booster-5-6.png"}; //String für die Boostermax abweichung
    private int bild = 0;
    private int boost = 0;
    private long letzterWechsel = System.currentTimeMillis(); // Zeitstempel des letzten Bildwechsels (in Millisekunden)
    private int Wechseltime = 50; // Mindestabstand zwischen zwei Animationsframes in ms (unabhängig von der Spielgeschwindigkeit)
    boolean Hot; // true = Booster gerade aktiv (W gedrückt), löst Abkühl-Animation aus wenn losgelassen
    int Scale=5; // Teiler für die Bildskalierung – hier zentral ändern um Schiffgröße anzupassen

    //#Bewegungs Variablen
    float SpeedX; float AcclX;
    float SpeedY; float AcclY; //Beschleunigung und Geschwindigkeit
    float SpeedRot;
    int Rotation; //Variable in welcher die Aktuelle Rotation des Shiffes gespeichert wird.
    float posX, posY; // echte Position als float

    float Beschleunigung = 0.3f; // f dafür dass Java weiß dass es ein Float ist.
    float Reibung = 0.99f;
    float ReibungRot = 0.90f;

    //#Schuss Variablen
    private int shootCooldown = 0;
    private static final int SHOOT_DELAY = 60; // Automatischer Schuss alle 60 Act-Schritte (~1 Sekunde)

    //#Sprit Variablen
    private int sprit = 1000;
    private static final int MAX_SPRIT = 1000;

    //#Leben Variablen
    private int leben = 8;
    private int maxLeben = 8;
    // Nach einem Treffer kurz unverwundbar, damit nicht mehrere Leben auf einmal verloren gehen
    private int unverwundbarkeit = 0;
    private static final int UNVERWUNDBAR_DAUER = 90; // Acts lang unverwundbar nach Treffer (~1,5 Sek)

    //# Sound's
    private int loopVolume = 0;
    private boolean fadingIn = false;
    private boolean fadingOut = false;
    private int fadeDelay = 0;

    private GreenfootSound launch = new GreenfootSound("launch.mp3");
    private GreenfootSound loop = new GreenfootSound("loop.mp3");
    private GreenfootSound woosh = new GreenfootSound("woosh.mp3");
    private GreenfootSound crash = new GreenfootSound("crash.mp3");

    public Player() {
        GreenfootImage img = getImage();
        img.scale(img.getWidth() / Scale, img.getHeight() / Scale); // Bildskalierung
    }

    public void addedToWorld(World world) {
        posX = getX();  //Position Festlegen
        posY = getY();
    }

    public void act()
    {
        if (!loop.isPlaying()) {
            loop.setVolume(20);
            loopVolume=20;
            loop.playLoop(); // nur einmal starten
        }
        // Booster losgelassen: Abkühl-Animation + Sound leiser werden
        if(Hot&&!Greenfoot.isKeyDown("w")){
            boostercool();
            fadingIn = false;
            fadingOut = true;
        }
        // Booster aktiv: Flammen-Animation + Sound lauter werden
        if(Hot&&Greenfoot.isKeyDown("w")){
            boostermax();
            fadingOut = false;
            fadingIn = true;
        }
        AudioFade();

        Bewegung();
        Schiessen();
        // Geschwindigkeit auf Position anwenden
        posX += SpeedX;
        posY += SpeedY;
        turn(Math.round(SpeedRot));
        SpeedRot *= ReibungRot;

        // Reibung für den Spieler
        SpeedX *= Reibung;
        SpeedY *= Reibung;
        setLocation(Math.round(posX), Math.round(posY)); //Math.round, da setLocation nur ganze Zahlen verkraftet :(
        OutofBoundaries();
        checkAsteroidCollision();

        // Unverwundbarkeit runterzählen
        if (unverwundbarkeit > 0) unverwundbarkeit--;

        //Debug();
    }

    public void Bewegung(){ //# Tastaturinputs in Bewegung
        // Vorwärts (W)
        if (Greenfoot.isKeyDown("w") && sprit > 0) {
            double rad = Math.toRadians(getRotation()); // Rotation in Bogenmaß → nötig für Math.cos/sin
            // cos/sin zerlegen die Blickrichtung in X- und Y-Anteil (Trigonometrie)
            AcclX = (float)(Math.cos(rad) * Beschleunigung); //# Gibt den X-Anteil der Beschleunigung an
            AcclY = (float)(Math.sin(rad) * Beschleunigung);

            SpeedX += AcclX;
            SpeedY += AcclY;
            Hot=true;

            sprit--;
            java.util.List<Spritanzeige> spritAnzeigen = getWorld().getObjects(Spritanzeige.class);
            if (!spritAnzeigen.isEmpty()) {
                spritAnzeigen.get(0).update(sprit);
            }
        }
        // Links (A) – SpeedRot negativ = Drehung gegen den Uhrzeigersinn
        if (Greenfoot.isKeyDown("a")) {
            SpeedRot -= 0.3;
        }

        // Rechts (D) – SpeedRot positiv = Drehung im Uhrzeigersinn
        if (Greenfoot.isKeyDown("d")) {
            SpeedRot += 0.3;
        }
    }

    public void Schiessen() { //# Feuert automatisch alle SHOOT_DELAY Schritte in Blickrichtung
        shootCooldown--; // Zähler läuft jeden Act runter
        if (shootCooldown <= 0) { // wenn Countdown abgelaufen → schießen und zurücksetzen
            double rad = Math.toRadians(getRotation());
            // Spawn-Punkt 30 Pixel vor der Schiffsspitze, damit das Projektil nicht sofort kollidiert
            float spawnX = posX + (float)(Math.cos(rad) * 30);
            float spawnY = posY + (float)(Math.sin(rad) * 30);
            Projectile p = new Projectile(getRotation());
            getWorld().addObject(p, Math.round(spawnX), Math.round(spawnY));
            shootCooldown = SHOOT_DELAY;
        }
    }

    public void OutofBoundaries(){
        int worldWidth = getWorld().getWidth();
        int worldHeight = getWorld().getHeight();

        // X begrenzen
        if (posX < 0) {posX = worldWidth - 1;}
        if (posX > worldWidth - 1) {posX = 0;}

        // Y begrenzen
        if (posY < 0) {posY = worldHeight - 1;}
        if (posY > worldHeight - 1) {posY = 0;}
    }

    public void setzeBild(String dateiname){
        GreenfootImage bild= new GreenfootImage(dateiname); //Neues Bild "erstellen"
        bild.scale(bild.getWidth() / Scale, bild.getHeight() / Scale);   //Bild auf 1/4 der Größe Skallieren
        setImage(bild); //Bild setzen

    }

    public void boostercool(){
        long jetzt = System.currentTimeMillis();
        if (jetzt - letzterWechsel >= Wechseltime) {
            letzterWechsel = jetzt;
            // bild++ zählt hoch, % bilder.length springt zurück auf 0 wenn das Ende erreicht ist (Modulo-Trick)
            setzeBild(bilder[bild++ % bilder.length]); //#noch einmal erklären lassen
            woosh.setVolume(60);
            woosh.play();
        }
        // Alle Abkühl-Frames wurden gezeigt → Animation fertig, zurück zum normalen Schiff-Bild
        if (bild >= bilder.length) {
            Hot = false;
            bild = 0;
            setzeBild("Ship.png");
        }
    }

    public void boostermax(){
        long jetzt = System.currentTimeMillis();
        if (jetzt - letzterWechsel >= Wechseltime) {
            letzterWechsel = jetzt;
            // Gleicher Modulo-Trick wie in boostercool, aber für die Flammen-Animation
            setzeBild(booster[boost++ % booster.length]); //#noch einmal erklären lassen
        }
    }

    private void AudioFade(){
        fadeDelay++;
        if (fadeDelay < 2) return; // nur jede 2. Act-Runde ausführen
        fadeDelay = 0;

        // Lautstärke: 20 = Leerlauf, 40 = Vollgas (Boost aktiv)
        if (fadingIn && loopVolume < 40) {
            loopVolume += 1;
            loop.setVolume(loopVolume);
            if (loopVolume >= 40) fadingIn = false;
        }
        if (fadingOut && loopVolume > 20) {
            loopVolume -= 1;
            loop.setVolume(loopVolume);
            if (loopVolume <= 20) {
                fadingOut = false;
            }
        }
    }

    private void checkAsteroidCollision() {
        // Wir suchen alle Asteroiden in der Nähe
        // Wir holen uns alle Asteroiden aus der Welt
        for (Asteroids a : getWorld().getObjects(Asteroids.class)) {
            // Abstand berechnen mit den float-Positionen aus Asteroids  und Player
            float dx = this.posX - a.posX;
            float dy = this.posY - a.posY;
            float distance = (float)Math.sqrt(dx * dx + dy * dy);

            // Schiff-Radius (50) + size-abhängiger Asteroid-Radius
            int collisionDist = 50 + a.getHitRadius();

            if (distance < collisionDist) {
                // --- DER ABPRALL-EFFEKT ---
                float bouncePower = 8.0f; // Wie stark der Stoß ist

                // Normalisierung des Vektors (Richtung bestimmen)
                // Wir teilen durch die Distanz, damit der Vektor die Länge 1 hat
                // distance > 0: Schutz vor Division durch Null
                if (distance > 0) {
                    // Normalisierter Richtungsvektor (Länge 1) × Stärke = neue Abprall-Geschwindigkeit
                    this.SpeedX = (dx / distance) * bouncePower;
                    this.SpeedY = (dy / distance) * bouncePower;
                }

                // Optional: Ein bisschen Rotation hinzufügen für den Realismus
                this.SpeedRot = Greenfoot.getRandomNumber(10) - 5;

                
                crash.play();

                // Leben abziehen – aber nur wenn gerade nicht unverwundbar
                if (unverwundbarkeit == 0) {
                    leben--;
                    unverwundbarkeit = UNVERWUNDBAR_DAUER;

                    // Lebensanzeige aktualisieren
                    java.util.List<Lebensanzeige> anzeigen = getWorld().getObjects(Lebensanzeige.class);
                    if (!anzeigen.isEmpty()) {
                        anzeigen.get(0).update(leben);
                    }

                    // Bei 0 Leben: Game Over
                    if (leben <= 0) {
                        ((MyWorld)getWorld()).gameOver();
                    }
                }
            }
        }
    }

    public void tankAuffuellen(int menge) {
        sprit = Math.min(sprit + menge, MAX_SPRIT);
        java.util.List<Spritanzeige> spritAnzeigen = getWorld().getObjects(Spritanzeige.class);
        if (!spritAnzeigen.isEmpty()) {
            spritAnzeigen.get(0).update(sprit);
        }
    }

    // Debug-Methode: zeichnet den Kollisionskreis (Radius 55) sichtbar auf den Hintergrund.
    // Aufruf in act() einkommentieren um die Hitbox zu überprüfen.
    private void Debug() {

        GreenfootImage bg = getWorld().getBackground();
        bg.setColor(Color.RED);
        // Zeichnet einen Kreis um die aktuelle Position
        bg.drawOval((int)posX - 55, (int)posY - 55, 110, 110);
    }
}
