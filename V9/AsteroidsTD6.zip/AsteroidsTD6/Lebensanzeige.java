import greenfoot.*;

public class Lebensanzeige extends Actor
{
    private int maxLeben;
    private GreenfootImage volleBild; // Das gesamte Sprite-Sheet mit allen Lebenszuständen
    private static final int ANZEIGE_BREITE = 300; // Anzeigebreite in Pixeln (anpassbar)

    public Lebensanzeige(int maxLeben) {
        this.maxLeben = maxLeben;
        volleBild = new GreenfootImage("Lebensanzeige.png");
        update(maxLeben); // Start mit vollem Leben anzeigen
    }

    // Schneidet die passende Zeile aus dem Sprite-Sheet und setzt sie als Bild.
    // Jede Zeile steht für einen Lebenszustand: Zeile 0 = voll, Zeile maxLeben-1 = fast leer.
    public void update(int leben) {
        int zeilenHoehe = volleBild.getHeight() / maxLeben;
        // Zeile 0 = volles Leben (oben), höherer Index = weniger Leben
        int zeilenIndex = maxLeben - leben;

        // Neues Bild in Zeilengröße erstellen und nur die gewünschte Zeile hineinkopieren.
        // Negativer Y-Versatz schiebt das Quellbild nach oben, sodass nur die richtige Zeile sichtbar ist.
        GreenfootImage ausschnitt = new GreenfootImage(volleBild.getWidth(), zeilenHoehe);
        ausschnitt.drawImage(volleBild, 0, -zeilenIndex * zeilenHoehe);

        // Auf Anzeigebreite skalieren (Höhe proportional mitgerechnet)
        int skaliertHoehe = (int)((double)zeilenHoehe / volleBild.getWidth() * ANZEIGE_BREITE);
        ausschnitt.scale(ANZEIGE_BREITE, skaliertHoehe);

        setImage(ausschnitt);
    }

    public void act() {
        // Lebensanzeige bewegt sich nicht und braucht keine eigene Logik
    }
}
