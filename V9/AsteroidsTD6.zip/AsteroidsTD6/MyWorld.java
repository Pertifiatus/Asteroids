import greenfoot.*;

public class MyWorld extends World
{
    public static int level = 1;

    private boolean transitioning = false;
    private int uebergangsTimer = 0;
    private static final int UEBERGANGS_DAUER = 150; // ~2,5 Sek bei 60 Acts/Sek

    private boolean gameOver = false;
    private int gameOverTimer = 0;
    private static final int GAME_OVER_DAUER = 180; // 3 Sek bei 60 Acts/Sek

    private LevelAnzeige levelAnzeige;

    public MyWorld()
    {
        super(2000, 1000, 1);
        setBackground(new GreenfootImage("Background.png"));

        level = 1; // Sicherstellen dass Level beim Neustart zurückgesetzt wird

        Player spieler = new Player();
        addObject(spieler, getWidth() / 2, getHeight() / 2);

        // Lebensanzeige oben links
        Lebensanzeige lebensAnzeige = new Lebensanzeige(8);
        addObject(lebensAnzeige, lebensAnzeige.getImage().getWidth() / 2 + 20,
                                 lebensAnzeige.getImage().getHeight() / 2 + 20);

        // Spritanzeige unter der Lebensanzeige
        Spritanzeige spritAnzeige = new Spritanzeige(1000);
        int spritY = lebensAnzeige.getImage().getHeight() + 30 + spritAnzeige.getImage().getHeight() / 2;
        addObject(spritAnzeige, spritAnzeige.getImage().getWidth() / 2 + 20, spritY);

        // Levelanzeige oben mittig
        levelAnzeige = new LevelAnzeige(level);
        addObject(levelAnzeige, getWidth() / 2, 25);

        starteLevel(level);
    }

    public void gameOver() {
        if (gameOver) return;
        gameOver = true;
        gameOverTimer = GAME_OVER_DAUER;
        levelAnzeige.zeigeGameOver();
        levelAnzeige.setLocation(getWidth() / 2, getHeight() / 2);
        removeObjects(getObjects(Player.class));
    }

    public void act() {
        if (gameOver) {
            gameOverTimer--;
            if (gameOverTimer <= 0) {
                Greenfoot.setWorld(new MyWorld());
            }
            return;
        }
        if (transitioning) {
            uebergangsTimer--;
            if (uebergangsTimer <= 0) {
                transitioning = false;
                level++;
                starteLevel(level);
            }
        } else if (getObjects(Asteroids.class).isEmpty()) {
            // Alle Asteroiden zerstört → Level-Abschluss einleiten
            transitioning = true;
            uebergangsTimer = UEBERGANGS_DAUER;

            levelAnzeige.zeigeNachricht("Level " + level + " - Geschafft!");
            levelAnzeige.setLocation(getWidth() / 2, getHeight() / 2);

            // Sprit-Bonus für nächstes Level
            java.util.List<Player> players = getObjects(Player.class);
            if (!players.isEmpty()) {
                players.get(0).tankAuffuellen(400);
            }
        }
    }

    private void starteLevel(int level) {
        // Alte Projektile entfernen damit nichts aus dem letzten Level übrig bleibt
        removeObjects(getObjects(Projectile.class));

        // Levelanzeige zurück oben mittig
        levelAnzeige.zeigeLevel(level);
        levelAnzeige.setLocation(getWidth() / 2, 25);

        // Asteroid-Anzahl: Level 1 = 2, Level 2 = 3, Level 3 = 4 …
        int anzahl = level + 1;
        for (int i = 0; i < anzahl; i++) {
            int posX = Greenfoot.getRandomNumber(getWidth());
            int posY = Greenfoot.getRandomNumber(getHeight());
            addObject(new Asteroids(), posX, posY);
        }
    }
}
