import greenfoot.*;

public class LevelAnzeige extends Actor
{
    public LevelAnzeige(int level) {
        zeigeLevel(level);
    }

    public void zeigeLevel(int level) {
        GreenfootImage img = new GreenfootImage(220, 38);
        img.setFont(new Font("Arial", true, false, 26));
        img.setColor(Color.WHITE);
        img.drawString("Level  " + level, 10, 30);
        setImage(img);
    }

    // Große zentrierte Übergangs-Nachricht (z.B. "Level 2 – Geschafft!")
    public void zeigeNachricht(String text) {
        GreenfootImage img = new GreenfootImage(620, 70);
        img.setFont(new Font("Arial", true, false, 44));
        img.setColor(new Color(255, 220, 50));
        img.drawString(text, 10, 56);
        setImage(img);
    }

    public void zeigeGameOver() {
        GreenfootImage img = new GreenfootImage(700, 120);
        img.setFont(new Font("Arial", true, false, 90));
        img.setColor(new Color(220, 30, 30));
        img.drawString("GAME OVER", 10, 100);
        setImage(img);
    }

    public void act() {}
}
