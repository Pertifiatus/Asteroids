import greenfoot.*;

public class Projectile extends Actor
{
    float posX, posY;
    float speedX, speedY; // Geschwindigkeit in X/Y-Richtung, berechnet aus Rotation
    private static final float SPEED = 14.0f; // Geschwindigkeit des Projektils in Pixel pro Act
    private GreenfootSound explosion = new GreenfootSound("explosion.mp3");
    public Projectile(int rotation) {
        // Rotation in X/Y-Komponenten aufteilen (gleiche Trigonometrie wie beim Schiff)
        double rad = Math.toRadians(rotation);
        speedX = (float)(Math.cos(rad) * SPEED);
        speedY = (float)(Math.sin(rad) * SPEED);

        // Projektil als kleinen weißen Kreis zeichnen (kein externes Bild nötig)
        GreenfootImage img = new GreenfootImage(8, 8);
        img.setColor(Color.WHITE);
        img.fillOval(0, 0, 8, 8);
        setImage(img);
    }

    // getX()/getY() funktionieren erst nachdem der Actor zur Welt hinzugefügt wurde
    public void addedToWorld(World world) {
        posX = getX();
        posY = getY();
    }

    public void act() {
        posX += speedX;
        posY += speedY;
        setLocation(Math.round(posX), Math.round(posY));

        // Projektil verschwinden lassen wenn es den Rand verlässt (kein Wrap-around)
        int w = getWorld().getWidth();
        int h = getWorld().getHeight();
        if (posX < 0 || posX >= w || posY < 0 || posY >= h) {
            getWorld().removeObject(this);
            return; // return nötig: nach removeObject wäre getWorld() null → NullPointerException
        }

        // Trifft das Projektil einen Asteroiden?
        Asteroids hit = (Asteroids) getOneIntersectingObject(Asteroids.class);
        if (hit != null) {
            hit.split();
            explosion.setVolume(40);
            explosion.play();
            getWorld().removeObject(this);
        }
    }
}
