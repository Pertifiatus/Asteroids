import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot und MouseInfo)

/**
 * Ergänzen Sie hier eine Beschreibung für die Klasse Asteroids.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Asteroids extends Actor
{

    float posX, posY;   //Positionen der Asteroiden
    float SpeedX;   //Variablen für die Anfangsgeschwindigkeit
    float SpeedY;   //Variablen für die Anfangsgeschwindigkeit
    float Rotation; //Variablen für die Anfangsrotation
    public void act() {
        posX += SpeedX;
        posY += SpeedY;

        turn(Math.round(Rotation));
        setLocation(Math.round(posX), Math.round(posY)); //Math.round, da setLocation nur ganze Zahlen verkraftet :(
        OutofBoundaries();
        checkHitbox();
    }    

    public void addedToWorld(World world) { 
        posX = getX();  //Position Festlegen
        posY = getY();
        SpeedX=Greenfoot.getRandomNumber(10)-5;     //Anfangsgeschwindigkeit & Rotation
        SpeedY=Greenfoot.getRandomNumber(10)-5;
        Rotation=Greenfoot.getRandomNumber(5)-2.5f;
    }

    public Asteroids() {            //Wird vor addedToWorld ausgeführt, da er da noch erstellt wird.
        GreenfootImage img = getImage();    
        img.scale(img.getWidth() / 3, img.getHeight() / 3); // Bildskalierung

    }

    public void OutofBoundaries(){
        int worldWidth = getWorld().getWidth(); //Weltengröße auslesen
        int worldHeight = getWorld().getHeight();   //Weltengröße auslesen

        // X begrenzen
        if (posX < 0) {posX = worldWidth - 1;}
        if (posX > worldWidth - 1) {posX = 0;}

        // Y begrenzen
        if (posY < 0) {posY = worldHeight - 1;} // Wenn Spieler ganz Links, dann nach ganz Rechts
        if (posY > worldHeight - 1) {posY = 0;} // Wenn Spieler ganz Rechts, dann nach ganz Links
    }

    public void checkHitbox()
{
    if(getWorld().getObjects(Player.class).isEmpty())
    {
        return;
    }

    Player player = (Player)getWorld().getObjects(Player.class).get(0);

    int dx = player.getX() - getX();
    int dy = player.getY() - getY();

    int radius = 100;

    if(dx * dx + dy * dy <= radius * radius)
    {
        SpeedX = -SpeedX;
        SpeedY = -SpeedY;
    }
}
    
    
}