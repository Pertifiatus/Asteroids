import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot und MouseInfo)

public class Player extends Actor
{

    float SpeedX; float AcclX;
    float SpeedY; float AcclY; //Beschleunigung und Geschwindigkeit
    float SpeedRot;
    int Rotation; //Variable in welcher die Aktuelle Rotation des Shiffes gespeichert wird. 
    float posX, posY; // echte Position als float

    float Beschleunigung = 0.3f; // f dafür dass Java weiß dass es ein Float ist.
    float BoundaryAccl = 0.5f;
    float Reibung = 0.99f;
    float ReibungRot = 0.90f;

    public Player() {
        GreenfootImage img = getImage();
        img.scale(img.getWidth() / 8, img.getHeight() / 8); // halb so groß
    }

    public void addedToWorld(World world) {
        posX = getX();  //Position Festlegen
        posY = getY();
    }

    public void act() 
    {

        Bewegung();
        // Geschwindigkeit auf Position anwenden
        posX += SpeedX;
        posY += SpeedY;
        turn(Math.round(SpeedRot));
        SpeedRot *= ReibungRot;
        // Reibung für den Spieler
        SpeedX *= Reibung;
        SpeedY *= Reibung;
        setLocation(Math.round(posX), Math.round(posY)); //Math.round, da setLocation nur ganze Zahlen verkraftet :(
        OutofBoundaries();
    }   

    public void Bewegung(){ //# Tastaturinputs in Bewegung
        // Vorwärts (W)
        if (Greenfoot.isKeyDown("w")) {
            double rad = Math.toRadians(getRotation()); // Umwandlung von Radiant zu Bogenmaß
            AcclX = (float)(Math.cos(rad) * Beschleunigung); //# Gibt den X-Anteil der Beschleunigung an
            AcclY = (float)(Math.sin(rad) * Beschleunigung); 

            SpeedX += AcclX;
            SpeedY += AcclY;
        }

        // Links (A)
        if (Greenfoot.isKeyDown("a")) {
            SpeedRot -= 0.5;
        }

        // Rechts (D)
        if (Greenfoot.isKeyDown("d")) {
            SpeedRot += 0.5;
        }
    }

    public void OutofBoundaries(){
        int worldWidth = getWorld().getWidth();
        int worldHeight = getWorld().getHeight();

        // X begrenzen
        if (posX < 0) {posX = worldWidth - 1;}
        if (posX > worldWidth - 1) {posX = 0;}

        // Y begrenzen
        if (posY < 0) {posY = worldHeight - 1;}
        if (posY > worldHeight - 1) {posY = 0;}
    }
}