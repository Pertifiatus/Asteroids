import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot und MouseInfo)

/**
 * Ergänzen Sie hier eine Beschreibung für die Klasse Asteroids.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Asteroids extends Actor
{
    float posX, posY; // echte Position als float
    float SpeedX;
    float SpeedY;
    public void act() {
        setLocation(Math.round(posX), Math.round(posY)); //Math.round, da setLocation nur ganze Zahlen verkraftet :(
        
        
        
        
        
    }    

    public void addedToWorld(World world) {
        posX = getX();  //Position Festlegen
        posY = getY();
        
    }
}