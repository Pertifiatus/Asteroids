import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot und MouseInfo)

public class Player extends Actor
{
    //# Bilder Variablen
    private String[] bilder = {"Booster-5-1.png", "Booster-4.png", "Booster-3.png", "Booster-2.png", "Booster-1.png"}; //String für die Booster Abkühlung
    private String[] booster = {"Booster-5-1.png", "Booster-5-2.png", "Booster-5-3.png", "Booster-5-4.png", "Booster-5-5.png", "Booster-5-6.png"}; //String für die Boostermax abweichung
    private int bild = 0;
    private int boost = 0;
    private long letzterWechsel = System.currentTimeMillis();
    private int Wechseltime = 50;
    boolean Hot;
    int Scale=5;

    //#Bewegungs Variablen
    float SpeedX; float AcclX;
    float SpeedY; float AcclY; //Beschleunigung und Geschwindigkeit
    float SpeedRot;
    int Rotation; //Variable in welcher die Aktuelle Rotation des Shiffes gespeichert wird. 
    float posX, posY; // echte Position als float

    float Beschleunigung = 0.3f; // f dafür dass Java weiß dass es ein Float ist.
    float Reibung = 0.99f;
    float ReibungRot = 0.90f;

    public Player() {
        GreenfootImage img = getImage();
        img.scale(img.getWidth() / Scale, img.getHeight() / Scale); // Bildskalierung
    }

    public void addedToWorld(World world) {
        posX = getX();  //Position Festlegen
        posY = getY();
    }

    public void act() 
    {
        Bewegung(); //W A D für Steuerung werden aufgezeichnet
        Positioning(); //Die Bewegung wird ausgerechnet und auf den Spieler angepasst
        Animation(); //Frontend für die Animation des Schiffes
    }   

    //# GAS GAS GAS Im gonna step on the gas... TONIGHT...
    
    
    public void Bewegung(){ //# Tastaturinputs in Bewegung
        // Vorwärts (W)
        if (Greenfoot.isKeyDown("w")) {
            double rad = Math.toRadians(getRotation()); // Umwandlung von Radiant zu Bogenmaß
            AcclX = (float)(Math.cos(rad) * Beschleunigung); //# Gibt den X-Anteil der Beschleunigung an
            AcclY = (float)(Math.sin(rad) * Beschleunigung); 

            SpeedX += AcclX;
            SpeedY += AcclY;
            Hot=true;
        }
        // Links (A)
        if (Greenfoot.isKeyDown("a")) {
            SpeedRot -= 0.5;
        }

        // Rechts (D)
        if (Greenfoot.isKeyDown("d")) {
            SpeedRot += 0.5;
        }
    }

    public void Positioning(){
        posX += SpeedX;
        posY += SpeedY;
        turn(Math.round(SpeedRot));
        SpeedRot *= ReibungRot;

        // Reibung für den Spieler
        SpeedX *= Reibung;
        SpeedY *= Reibung;
        setLocation(Math.round(posX), Math.round(posY)); //Math.round, da setLocation nur ganze Zahlen verkraftet :(
        OutofBoundaries();
    }

    public void OutofBoundaries(){
        int worldWidth = getWorld().getWidth();
        int worldHeight = getWorld().getHeight();

        // X begrenzen
        if (posX < 0) {posX = worldWidth - 1;}
        if (posX > worldWidth - 1) {posX = 0;}

        // Y begrenzen
        if (posY < 0) {posY = worldHeight - 1;}
        if (posY > worldHeight - 1) {posY = 0;}
    }

    
    //# Uii shiney
    
    public void Animation(){
        if(Hot&&!Greenfoot.isKeyDown("w")){
            boostercool();
        }
        if(Hot&&Greenfoot.isKeyDown("w")){
            boostermax();
        }
    }

    public void boostercool(){
        long jetzt = System.currentTimeMillis();
        if (jetzt - letzterWechsel >= Wechseltime) {
            letzterWechsel = jetzt;
            setzeBild(bilder[bild++ % bilder.length]); //Modulo für hochzählen der Bilder
        }
        if (bild >= bilder.length) {
            Hot = false;
            bild = 0;
            setzeBild("Ship.png");
        }
    }

    public void boostermax(){
        long jetzt = System.currentTimeMillis();
        if (jetzt - letzterWechsel >= Wechseltime) {
            letzterWechsel = jetzt;
            setzeBild(booster[boost++ % booster.length]); //Modulo für hochzählen der Bilder
        }
    }
    
    
    
    //# Hilfsfunktionen
    
    public void setzeBild(String dateiname){
        GreenfootImage bild= new GreenfootImage(dateiname); //Neues Bild "erstellen"
        bild.scale(bild.getWidth() / Scale, bild.getHeight() / Scale);   //Bild auf 1/4 der Größe Skallieren
        setImage(bild); //Bild setzen

    }
    
}