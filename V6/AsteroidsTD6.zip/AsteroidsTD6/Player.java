import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot und MouseInfo)

public class Player extends Actor
{
    //# Bilder Variablen
    private String[] bilder = {"Booster-5-1.png", "Booster-4.png", "Booster-3.png", "Booster-2.png", "Booster-1.png"}; //String für die Booster Abkühlung
    private String[] booster = {"Booster-5-1.png", "Booster-5-2.png", "Booster-5-3.png", "Booster-5-4.png", "Booster-5-5.png", "Booster-5-6.png"}; //String für die Boostermax abweichung
    private int bild = 0;
    private int boost = 0;
    private long letzterWechsel = System.currentTimeMillis();
    private int Wechseltime = 50;
    boolean Hot;
    int Scale=5;

    //#Bewegungs Variablen
    float SpeedX; float AcclX;
    float SpeedY; float AcclY; //Beschleunigung und Geschwindigkeit
    float SpeedRot;
    int Rotation; //Variable in welcher die Aktuelle Rotation des Shiffes gespeichert wird. 
    float posX, posY; // echte Position als float

    float Beschleunigung = 0.3f; // f dafür dass Java weiß dass es ein Float ist.
    float Reibung = 0.99f;
    float ReibungRot = 0.90f;

    //# Sound's
    private int loopVolume = 0;
    private boolean fadingIn = false;
    private boolean fadingOut = false;
    private int fadeDelay = 0;

    private GreenfootSound launch = new GreenfootSound("launch.mp3");
    private GreenfootSound loop = new GreenfootSound("loop.mp3");
    private GreenfootSound woosh = new GreenfootSound("woosh.mp3");

    public Player() {
        GreenfootImage img = getImage();
        img.scale(img.getWidth() / Scale, img.getHeight() / Scale); // Bildskalierung
    }

    public void addedToWorld(World world) {
        posX = getX();  //Position Festlegen
        posY = getY();
    }

    public void act() 
    {
        if (!loop.isPlaying()) {
            loop.setVolume(20);
            loopVolume=20;
            loop.playLoop(); // nur einmal starten
        }
        if(Hot&&!Greenfoot.isKeyDown("w")){
            boostercool();
            fadingIn = false;
            fadingOut = true;
        }
        if(Hot&&Greenfoot.isKeyDown("w")){
            boostermax();
            fadingOut = false;
            fadingIn = true;
        }
        AudioFade();

        Bewegung();
        // Geschwindigkeit auf Position anwenden
        posX += SpeedX;
        posY += SpeedY;
        turn(Math.round(SpeedRot));
        SpeedRot *= ReibungRot;

        // Reibung für den Spieler
        SpeedX *= Reibung;
        SpeedY *= Reibung;
        setLocation(Math.round(posX), Math.round(posY)); //Math.round, da setLocation nur ganze Zahlen verkraftet :(
        OutofBoundaries();
        checkAsteroidCollision();

        //Debug();
    }   

    public void Bewegung(){ //# Tastaturinputs in Bewegung
        // Vorwärts (W)
        if (Greenfoot.isKeyDown("w")) {
            double rad = Math.toRadians(getRotation()); // Umwandlung von Radiant zu Bogenmaß
            AcclX = (float)(Math.cos(rad) * Beschleunigung); //# Gibt den X-Anteil der Beschleunigung an
            AcclY = (float)(Math.sin(rad) * Beschleunigung); 

            SpeedX += AcclX;
            SpeedY += AcclY;
            Hot=true;
        }
        // Links (A)
        if (Greenfoot.isKeyDown("a")) {
            SpeedRot -= 0.5;
        }

        // Rechts (D)
        if (Greenfoot.isKeyDown("d")) {
            SpeedRot += 0.5;
        }
    }

    public void OutofBoundaries(){
        int worldWidth = getWorld().getWidth();
        int worldHeight = getWorld().getHeight();

        // X begrenzen
        if (posX < 0) {posX = worldWidth - 1;}
        if (posX > worldWidth - 1) {posX = 0;}

        // Y begrenzen
        if (posY < 0) {posY = worldHeight - 1;}
        if (posY > worldHeight - 1) {posY = 0;}
    }

    public void setzeBild(String dateiname){
        GreenfootImage bild= new GreenfootImage(dateiname); //Neues Bild "erstellen"
        bild.scale(bild.getWidth() / Scale, bild.getHeight() / Scale);   //Bild auf 1/4 der Größe Skallieren
        setImage(bild); //Bild setzen

    }

    public void boostercool(){
        long jetzt = System.currentTimeMillis();
        if (jetzt - letzterWechsel >= Wechseltime) {
            letzterWechsel = jetzt;
            setzeBild(bilder[bild++ % bilder.length]); //#noch einmal erklären lassen
            woosh.play();
        }
        if (bild >= bilder.length) {
            Hot = false;
            bild = 0;
            setzeBild("Ship.png");
        }
    }

    public void boostermax(){
        long jetzt = System.currentTimeMillis();
        if (jetzt - letzterWechsel >= Wechseltime) {
            letzterWechsel = jetzt;
            setzeBild(booster[boost++ % booster.length]); //#noch einmal erklären lassen
        }
    }

    private void AudioFade(){
        fadeDelay++;
        if (fadeDelay < 2) return; // nur jede 2. Act-Runde ausführen
        fadeDelay = 0;

        if (fadingIn && loopVolume < 40) {
            loopVolume += 1;
            loop.setVolume(loopVolume);
            if (loopVolume >= 40) fadingIn = false;
        }
        if (fadingOut && loopVolume > 20) {
            loopVolume -= 1;
            loop.setVolume(loopVolume);
            if (loopVolume <= 20) {
                fadingOut = false;
            }
        }
    }

    private void checkAsteroidCollision() {
        // Wir suchen alle Asteroiden in der Nähe
        // Radius des Schiffs (ca. 20-30 Pixel je nach Bild) + Radius Asteroid
        int collisionDist = 110; 

        // Wir holen uns alle Asteroiden aus der Welt
        for (Asteroids a : getWorld().getObjects(Asteroids.class)) {
            // Abstand berechnen mit den float-Positionen aus Asteroids  und Player 
            float dx = this.posX - a.posX;
            float dy = this.posY - a.posY;
            float distance = (float)Math.sqrt(dx * dx + dy * dy);

            if (distance < collisionDist) {
                // --- DER ABPRALL-EFFEKT ---
                float bouncePower = 8.0f; // Wie stark der Stoß ist

                // Normalisierung des Vektors (Richtung bestimmen)
                // Wir teilen durch die Distanz, damit der Vektor die Länge 1 hat
                if (distance > 0) {
                    this.SpeedX = (dx / distance) * bouncePower;
                    this.SpeedY = (dy / distance) * bouncePower;
                }

                // Optional: Ein bisschen Rotation hinzufügen für den Realismus
                this.SpeedRot = Greenfoot.getRandomNumber(10) - 5;

                // Sound abspielen (falls vorhanden)
                // woosh.play(); 
            }
        }
    }

    private void Debug() {

        GreenfootImage bg = getWorld().getBackground();
        bg.setColor(Color.RED);
        // Zeichnet einen Kreis um die aktuelle Position
        bg.drawOval((int)posX - 55, (int)posY - 55, 110, 110);
    }
}