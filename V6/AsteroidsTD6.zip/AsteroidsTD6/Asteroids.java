import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot und MouseInfo)

/**
 * Ergänzen Sie hier eine Beschreibung für die Klasse Asteroids.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Asteroids extends Actor
{
    float posX, posY; // echte Position als float
    float SpeedX;
    float SpeedY;
    float Rotation;
    public void act() {
        posX += SpeedX;
        posY += SpeedY;

        turn(Math.round(Rotation));
        setLocation(Math.round(posX), Math.round(posY)); //Math.round, da setLocation nur ganze Zahlen verkraftet :(
        OutofBoundaries();
        //checkAsteroidCollision();
    }    

    public void addedToWorld(World world) {
        posX = getX();  //Position Festlegen
        posY = getY();
        SpeedX=Greenfoot.getRandomNumber(10)-5;
        SpeedY=Greenfoot.getRandomNumber(10)-5;
        Rotation=Greenfoot.getRandomNumber(5)-2.5f;
    }

    public Asteroids() {
        GreenfootImage img = getImage();
        img.scale(img.getWidth() / 4, img.getHeight() / 4); // Bildskalierung

    }

    public void OutofBoundaries(){
        int worldWidth = getWorld().getWidth();
        int worldHeight = getWorld().getHeight();

        // X begrenzen
        if (posX < 0) {posX = worldWidth - 1;}
        if (posX > worldWidth - 1) {posX = 0;}

        // Y begrenzen
        if (posY < 0) {posY = worldHeight - 1;}
        if (posY > worldHeight - 1) {posY = 0;}
    }

    private void checkAsteroidCollision() {
        // Radius eines Asteroiden (da sie auf 1/3 skaliert sind, probier mal 30-40 Pixel) 
        float radius = 40.0f; 
        float collisionDist = radius * 2; 

        // Wir gehen alle anderen Asteroiden durch
        for (Asteroids other : getWorld().getObjects(Asteroids.class)) {
            if (other == this) continue; // Nicht mit sich selbst kollidieren!

            // Abstand berechnen (Satz des Pythagoras)
            float dx = this.posX - other.posX;
            float dy = this.posY - other.posY;
            float distance = (float)Math.sqrt(dx * dx + dy * dy);

            if (distance < collisionDist && distance > 0) {
                // --- DER ABPRALL-EFFEKT ---
                float bouncePower = 0.05f; // Ein kleiner Schubs reicht oft schon

                // Wir ändern die Geschwindigkeit basierend auf der Richtung zum anderen Asteroiden
                this.SpeedX += (dx / distance) * bouncePower;
                this.SpeedY += (dy / distance) * bouncePower;
            }
        }
    }
}